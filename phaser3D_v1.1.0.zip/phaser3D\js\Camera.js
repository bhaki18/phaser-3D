import Vector3 from "./Vector3.js";

class Camera {
    constructor() {
        this.position = new Vector3(0, 0, -10);
        this.rotation = new Vector3(0, 0, 0); // pitch, yaw, roll
        this.fov = 256;
    }

    moveForward(amount) {
        const sy = Math.sin(this.rotation.y);
        const cy = Math.cos(this.rotation.y);
        this.position.x += sy * amount;
        this.position.z += cy * amount;
    }

    moveRight(amount) {
        const sy = Math.sin(this.rotation.y);
        const cy = Math.cos(this.rotation.y);
        this.position.x += cy * amount;
        this.position.z -= sy * amount;
    }
}

export default Camera;
